<?php
// Tangkap form submission
$messageSent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Di sini bisa dikirim ke email atau disimpan ke database
    // mail("youremail@domain.com", "Pesan dari $name", $message, "From: $email");
    
    $messageSent = true;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact - Jamal Resto & Coffee</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background-color: #3f5336;
    color: #fff;
    font-family: 'Segoe UI', sans-serif;
}
.section-title {
    text-align: center;
    margin: 80px 0 40px;
    font-weight: 300;
    letter-spacing: 2px;
}
.form-control, .form-select {
    border-radius: 10px;
    background-color: #1c1c1c;
    color: #fff;
    border: 1px solid #444;
}
.form-control:focus, .form-select:focus {
    background-color: #111;
    color: #fff;
    border-color: #FF6F61;
    box-shadow: none;
}
.btn-primary {
    background-color: #FF6F61;
    border-color: #FF6F61;
    transition: 0.3s;
}
.btn-primary:hover {
    background-color: #fff;
    color: #FF6F61;
    border-color: #FF6F61;
}
.alert-success {
    background-color: #28a745;
    border: none;
    color: #fff;
}
</style>
</head>
<body>

<section class="container py-5">
<h2 class="section-title">Contact Us</h2>

<?php if($messageSent): ?>
<div class="alert alert-success text-center">
    Terima kasih! Pesan Anda telah terkirim.
</div>
<?php endif; ?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <form method="POST" action="">
            <div class="mb-3">
                <label for="name" class="form-label">Your Name</label>
                <input type="text" class="form-control form-control-lg" id="name" name="name" placeholder="Masukkan nama Anda" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Your Email</label>
                <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="Masukkan email Anda" required>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Write your message</label>
                <textarea class="form-control form-control-lg" id="message" name="message" rows="6" placeholder="Tulis pesan Anda di sini..." required></textarea>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary btn-lg px-5">Send Message</button>
            </div>
        </form>
    </div>
</div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>