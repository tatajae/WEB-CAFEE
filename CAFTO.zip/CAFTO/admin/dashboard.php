<?php
session_start();

if(!isset($_SESSION['login'])){
    header("Location: login.php");
    exit;
}

$menu = isset($_GET['menu']) ? $_GET['menu'] : "";
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Dashboard Cafe</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

/* background utama */
body{
background:#F5F1EB;
font-family:'Segoe UI',sans-serif;
}

/* sidebar */
.sidebar{
width:230px;
height:100vh;
position:fixed;
background:#3F5233;
padding-top:20px;
color:white;
}

/* logo */
.logo{
font-size:22px;
font-weight:bold;
text-align:center;
margin-bottom:20px;
}

/* menu sidebar */
.sidebar a{
display:block;
padding:12px 20px;
color:white;
text-decoration:none;
margin:5px 10px;
border-radius:8px;
}

.sidebar a:hover{
background:#A67C52;
}

/* konten */
.content{
margin-left:250px;
padding:30px;
}

/* card statistik */
.card-menu{
border:none;
border-radius:15px;
padding:20px;
color:white;
}

/* warna card */
.card-coffee{
background:#A67C52;
}

.card-food{
background:#3F5233;
}

.card-dessert{
background:#8C6239;
}

.card-reservasi{
background:#6A8E5A;
}

/* box konten */
.box{
background:white;
padding:25px;
border-radius:15px;
box-shadow:0 6px 15px rgba(0,0,0,0.1);
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
☕ CAFTO
</div>

<a href="dashboard.php">Dashboard</a>
<a href="dashboard.php?menu=coffee">Data Coffee</a>
<a href="dashboard.php?menu=makanan">Data Makanan</a>
<a href="dashboard.php?menu=dessert">Data Dessert</a>
<a href="dashboard.php?menu=reservasi">Reservasi</a>
<a href="dashboard.php?menu=gallery">Gallery</a>
<a href="logout.php">Logout</a>

</div>


<!-- CONTENT -->

<div class="content">

<div class="box">

<h3>Admin Cafe Dashboard</h3>
<hr>

<?php

switch($menu){

case "coffee":
include "data_coffee.php";
break;

case "makanan":
echo "<h4>Halaman Data Makanan</h4>";
break;

case "dessert":
echo "<h4>Halaman Data Dessert</h4>";
break;

case "reservasi":
echo "<h4>Halaman Reservasi</h4>";
break;

case "gallery":
echo "<h4>Halaman Gallery</h4>";
break;

default:
?>

<div class="row g-4">

<div class="col-md-3">

<div class="card-menu card-coffee">

<h5>Total Coffee</h5>
<h2>10</h2>
<p>Menu tersedia</p>

</div>

</div>

<div class="col-md-3">

<div class="card-menu card-food">

<h5>Makanan</h5>
<h2>8</h2>
<p>Menu tersedia</p>

</div>

</div>

<div class="col-md-3">

<div class="card-menu card-dessert">

<h5>Dessert</h5>
<h2>5</h2>
<p>Menu tersedia</p>

</div>

</div>

<div class="col-md-3">

<div class="card-menu card-reservasi">

<h5>Reservasi</h5>
<h2>3</h2>
<p>Pesanan masuk</p>

</div>

</div>

</div>

<?php } ?>

</div>

</div>

</body>
</html>