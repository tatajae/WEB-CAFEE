<?php
include "../config/koneksi.php";

$data = mysqli_query($conn,"SELECT * FROM coffee");
?>

<style>

body{
background:#F5F1EB;
font-family:'Segoe UI',sans-serif;
}

/* judul */
.judul{
color:#3F5233;
font-weight:bold;
}

/* tombol */
.btn-coffee{
background:#A67C52;
color:white;
border:none;
border-radius:20px;
padding:8px 16px;
}

.btn-coffee:hover{
background:#8c6239;
color:white;
}

/* table */
.table{
background:white;
border-radius:10px;
overflow:hidden;
}

.table thead{
background:#3F5233;
color:white;
}

/* gambar */
.img-menu{
width:80px;
border-radius:10px;
}

/* card container */
.box-menu{
background:white;
padding:25px;
border-radius:15px;
box-shadow:0 8px 20px rgba(0,0,0,0.1);
}

</style>


<div class="box-menu">

<div class="d-flex justify-content-between align-items-center mb-4">

<h4 class="judul">☕ Coffee Menu</h4>

<a href="tambah_coffee.php" class="btn btn-coffee">
+ Tambah Menu
</a>

</div>


<table class="table table-hover">

<thead>

<tr>
<th>No</th>
<th>Menu</th>
<th>Harga</th>
<th>Deskripsi</th>
<th>Gambar</th>
<th>Aksi</th>
</tr>

</thead>

<tbody>

<?php
$no=1;
while($d=mysqli_fetch_array($data)){
?>

<tr>

<td><?php echo $no++; ?></td>

<td>
<b><?php echo $d['nama_coffee']; ?></b>
</td>

<td>
Rp <?php echo number_format($d['harga']); ?>
</td>

<td>
<?php echo $d['deskripsi']; ?>
</td>

<td>
<img src="../gambar/<?php echo $d['gambar']; ?>" class="img-menu">
</td>

<td>

<a href="edit_coffee.php?id=<?php echo $d['id_coffee']; ?>" 
class="btn btn-warning btn-sm">
Edit
</a>

<a href="hapus_coffee.php?id=<?php echo $d['id_coffee']; ?>" 
class="btn btn-danger btn-sm"
onclick="return confirm('Yakin hapus menu ini?')">
Hapus
</a>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>