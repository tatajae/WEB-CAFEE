<?php
session_start();
?>

<style>
.login-bg{
background:linear-gradient(135deg,#3f5f4f,#6f8f7f);
padding:80px 0;
}

.box{
background:white;
padding:40px;
border-radius:20px;
width:350px;
box-shadow:0 20px 40px rgba(0,0,0,.2);
margin:auto;
}
</style>

<div class="login-bg">

<div class="box">

<h3 class="text-center mb-4">Login Admin</h3>

<?php
if(isset($_GET['pesan'])){
echo "<div class='alert alert-danger'>Login gagal / captcha salah</div>";
}
?>

<form method="post" action="admin/proses_login.php">

<input type="text" name="username" class="form-control mb-3" placeholder="Username" required>

<input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

<img src="admin/captcha.php?rand=<?php echo rand(); ?>" class="mb-2">

<input type="text" name="captcha" class="form-control mb-3" placeholder="Masukkan Captcha" required>

<button class="btn btn-success w-100">Login</button>

</form>

</div>

</div>