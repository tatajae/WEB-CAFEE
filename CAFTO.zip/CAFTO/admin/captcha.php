<?php
session_start();

/* buat kode captcha */
$kode = substr(str_shuffle("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"),0,5);
$_SESSION['captcha'] = $kode;

/* ukuran gambar */
$image = imagecreate(130,40);

/* warna */
$bg = imagecolorallocate($image,255,255,255);
$text = imagecolorallocate($image,0,0,0);
$line = imagecolorallocate($image,200,200,200);

/* garis tipis */
imageline($image,0,20,130,20,$line);

/* tampilkan text */
imagestring($image,5,30,10,$kode,$text);

/* output */
header("Content-type:image/png");
imagepng($image);
imagedestroy($image);

?>