<?php
include "../config/koneksi.php";

$id=$_GET['id'];

$data=mysqli_query($conn,"SELECT * FROM coffee WHERE id_coffee='$id'");
$d=mysqli_fetch_array($data);

if(isset($_POST['update'])){

$nama=$_POST['nama'];
$harga=$_POST['harga'];
$deskripsi=$_POST['deskripsi'];

$gambar=$_FILES['gambar']['name'];
$tmp=$_FILES['gambar']['tmp_name'];

if($gambar!=""){
move_uploaded_file($tmp,"../gambar/".$gambar);

mysqli_query($conn,"UPDATE coffee SET
nama_coffee='$nama',
harga='$harga',
deskripsi='$deskripsi',
gambar='$gambar'
WHERE id_coffee='$id'");
}else{

mysqli_query($conn,"UPDATE coffee SET
nama_coffee='$nama',
harga='$harga',
deskripsi='$deskripsi'
WHERE id_coffee='$id'");
}

header("location:dashboard.php?menu=coffee");
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#F5F1EB;
font-family:'Segoe UI';
}

.header{
background:#3F5233;
color:white;
padding:40px;
text-align:center;
}

.form-box{
background:white;
padding:30px;
border-radius:15px;
margin-top:-40px;
box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

.btn-cafe{
background:#A67C52;
color:white;
border-radius:30px;
}

</style>

<div class="header">
<h2>✏ Edit Menu Coffee</h2>
</div>

<div class="container">

<div class="form-box">

<form method="POST" enctype="multipart/form-data">

<label>Nama Coffee</label>
<input type="text" name="nama" class="form-control"
value="<?php echo $d['nama_coffee']; ?>">

<br>

<label>Harga</label>
<input type="number" name="harga" class="form-control"
value="<?php echo $d['harga']; ?>">

<br>

<label>Deskripsi</label>
<textarea name="deskripsi" class="form-control"><?php echo $d['deskripsi']; ?></textarea>

<br>

<label>Gambar Baru</label>
<input type="file" name="gambar" class="form-control">

<br>

<img src="../gambar/<?php echo $d['gambar']; ?>" width="120">

<br><br>

<button type="submit" name="update" class="btn btn-cafe">
Update Menu
</button>

<a href="dashboard.php?menu=coffee" class="btn btn-secondary">
Kembali
</a>

</form>

</div>

</div>