<?php
include "../config/koneksi.php";

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM coffee WHERE id_coffee='$id'");

header("location:dashboard.php?menu=coffee");
?>