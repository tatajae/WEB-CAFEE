<?php
include "../config/koneksi.php";

if(isset($_POST['simpan'])){

$nama = $_POST['nama'];
$harga = $_POST['harga'];
$deskripsi = $_POST['deskripsi'];

$gambar = $_FILES['gambar']['name'];
$tmp = $_FILES['gambar']['tmp_name'];

move_uploaded_file($tmp,"../gambar/".$gambar);

mysqli_query($conn,"INSERT INTO coffee VALUES
('','$nama','$harga','$deskripsi','$gambar')");

header("location:dashboard.php?menu=coffee");
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#F5F1EB;
font-family:'Segoe UI',sans-serif;
}

/* HEADER BESAR */
.hero{
background:#3F5233;
color:white;
padding:60px;
text-align:center;
}

.hero h2{
font-size:40px;
font-weight:bold;
}

/* CARD FORM */
.form-card{
background:white;
border-radius:20px;
padding:40px;
margin-top:-50px;
box-shadow:0 15px 30px rgba(0,0,0,0.2);
}

/* INPUT */
.form-control{
height:45px;
border-radius:10px;
}

/* BUTTON */
.btn-cafe{
background:#A67C52;
color:white;
padding:10px 25px;
border-radius:30px;
border:none;
}

.btn-cafe:hover{
background:#8c6239;
color:white;
}

/* PREVIEW GAMBAR */
.preview{
width:200px;
border-radius:15px;
margin-top:10px;
}

</style>

<div class="hero">
<h2>☕ Tambah Menu Coffee</h2>
<p>Tambahkan menu kopi baru ke dalam daftar cafe</p>
</div>

<div class="container">

<div class="row justify-content-center">

<div class="col-md-8">

<div class="form-card">

<form method="POST" enctype="multipart/form-data">

<div class="row">

<div class="col-md-6">

<label>Nama Coffee</label>
<input type="text" name="nama" class="form-control" required>

</div>

<div class="col-md-6">

<label>Harga</label>
<input type="number" name="harga" class="form-control" required>

</div>

</div>

<br>

<label>Deskripsi Menu</label>
<textarea name="deskripsi" class="form-control" rows="4"></textarea>

<br>

<label>Upload Gambar</label>
<input type="file" name="gambar" class="form-control" onchange="previewImage(event)">

<img id="preview" class="preview">

<br><br>

<button type="submit" name="simpan" class="btn btn-cafe">
Simpan Menu
</button>

<a href="dashboard.php?menu=coffee" class="btn btn-secondary">
Kembali
</a>

</form>

</div>

</div>

</div>

</div>

<script>

function previewImage(event){

var reader = new FileReader();

reader.onload = function(){
var output = document.getElementById('preview');
output.src = reader.result;
}

reader.readAsDataURL(event.target.files[0]);

}

</script>