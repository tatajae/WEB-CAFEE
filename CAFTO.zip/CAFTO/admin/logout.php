<?php
session_start();

// hapus semua session login
session_destroy();

// kembali ke halaman login (index.php)
header("Location: ../index.php");
exit;
?>