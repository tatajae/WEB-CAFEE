<?php
$nama_umkm = "Bakery Cafe";
$tagline = "Fresh Coffee & Pastries Every Day";
$deskripsi = "Tempat nongkrong cozy dengan kopi specialty dan pastry fresh setiap hari.";
$alamat = "Jl. Cafe No.10, Sukabumi";
$wa = "6281234567890";

if(isset($_GET['menu'])){
    $menu = $_GET['menu'];
}else{
    $menu = "";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title><?= $nama_umkm ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
font-family:Segoe UI;
scroll-behavior:smooth;
}

.navbar{
background:#3f5f4f;
}

.hero{
background:#3f5f4f;
color:white;
padding:140px 0;
}

.section-padding{
padding:80px 0;
}

.footer{
background:#3f5f4f;
color:white;
}

.dropdown:hover .dropdown-menu{
display:block;
margin-top:0;
}

</style>

</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
<div class="container">

<a class="navbar-brand" href="index.php"><?= $nama_umkm ?></a>

<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="nav">

<ul class="navbar-nav ms-auto">

<li class="nav-item">
<a class="nav-link" href="index.php">Home</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php?menu=About">About</a>
</li>

<li class="nav-item dropdown">

<a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
Menu
</a>

<ul class="dropdown-menu">

<li><a class="dropdown-item" href="index.php?menu=Coffe">Coffee</a></li>
<li><a class="dropdown-item" href="index.php?menu=Noncoffe">Non Coffee</a></li>
<li><a class="dropdown-item" href="index.php?menu=Makanan">Makanan</a></li>
<li><a class="dropdown-item" href="index.php?menu=Dessert">Dessert</a></li>

</ul>

</li>

<li class="nav-item">
<a class="nav-link" href="index.php?menu=Gallery">Gallery</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php?menu=Reservasi">Reservasi</a>
</li>

<li class="nav-item">
<a class="nav-link" href="index.php?menu=contact">Contact</a>
</li>

<li class="nav-item dropdown">

<a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
Daftar
</a>

<ul class="dropdown-menu">

<li><a class="dropdown-item" href="index.php?menu=login">Login Admin</a></li>
<li><a class="dropdown-item" href="index.php?menu=Noncoffe">Login Member</a></li>
<li><a class="dropdown-item" href="index.php?menu=Makanan">daftar</a></li>

</ul>

</li>

</div>
</div>
</nav>

<!-- HERO hanya tampil saat HOME -->
<?php if($menu==""){ ?>

<section class="hero">
<div class="container">
<div class="row align-items-center">

<div class="col-md-6">
<h1 class="fw-bold"><?= $tagline ?></h1>
<p><?= $deskripsi ?></p>

<a href="index.php?menu=Coffe" class="btn btn-light">Browse Menu</a>
<a href="https://wa.me/<?= $wa ?>" class="btn btn-outline-light">Order Online</a>
</div>

<div class="col-md-6">
<img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93"
class="img-fluid rounded">
</div>

</div>
</div>
</section>

<?php } ?>

<!-- CONTENT DINAMIS -->
<section class="section-padding">
<div class="container">

<?php include "menu.php"; ?>

</div>
</section>

<!-- FOOTER -->
<footer class="footer text-center py-3">
<small>&copy; <?= date('Y') ?> <?= $nama_umkm ?>. All Rights Reserved</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>