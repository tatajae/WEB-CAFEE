<?php

$gallery = [
["gambar"=>"https://images.unsplash.com/photo-1555396273-367ea4eb4db5","judul"=>"Cafe Interior"],
["gambar"=>"https://images.unsplash.com/photo-1504674900247-0877df9cc836","judul"=>"Delicious Food"],
["gambar"=>"https://images.unsplash.com/photo-1495474472287-4d71bcdd2085","judul"=>"Coffee Menu"],
["gambar"=>"https://images.unsplash.com/photo-1466978913421-dad2ebd01d17","judul"=>"Dessert"],
["gambar"=>"https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb","judul"=>"Cafe View"],
["gambar"=>"https://images.unsplash.com/photo-1521017432531-fbd92d768814","judul"=>"Fresh Drink"]
];

$reviews = [
["nama"=>"Andi","pesan"=>"Tempatnya sangat nyaman dan makanannya enak."],
["nama"=>"Sinta","pesan"=>"Kopi disini sangat nikmat dan pelayanannya ramah."],
["nama"=>"Budi","pesan"=>"Tempat nongkrong terbaik bersama teman."],
];

?>

<style>


/* GALLERY */
.gallery-img{
width:100%;
height:180px; /* tinggi proporsional untuk laptop */
object-fit:cover;
border-radius:8px;
transition:0.3s;
}

.gallery-img:hover{
transform:scale(1.03);
}

/* modal image */
.modal-img{
width:100%;
max-height:600px; /* batasi tinggi modal */
object-fit:cover;
}

/* REVIEW */
.review-box{
background:white;
padding:25px;
border-radius:10px;
box-shadow:0 5px 20px rgba(0,0,0,0.08);
max-width:450px; /* batasi lebar review */
margin:auto;
}

.section-title{
font-weight:bold;
margin-bottom:35px;
text-align:center;
}

</style>

<!-- ================= GALLERY ================= -->
<section class="container py-5">

<h2 class="section-title">Our Gallery</h2>

<div class="row g-4">
<?php foreach($gallery as $i=>$g){ ?>
<div class="col-lg-4 col-md-6">
<div class="card border-0 shadow-sm overflow-hidden">
<img src="<?php echo $g['gambar']; ?>" class="gallery-img" data-bs-toggle="modal" data-bs-target="#imgModal<?php echo $i; ?>" style="cursor:pointer">
<div class="card-body text-center">
<h6 class="fw-bold"><?php echo $g['judul']; ?></h6>
</div>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="imgModal<?php echo $i; ?>">
<div class="modal-dialog modal-dialog-centered modal-lg">
<div class="modal-content border-0">
<div class="modal-body p-0">
<img src="<?php echo $g['gambar']; ?>" class="modal-img">
</div>
</div>
</div>
</div>
<?php } ?>
</div>
</section>

<!-- ================= REVIEWS ================= -->
<section class="bg-light py-5">
<div class="container">
<h2 class="section-title">Customer Reviews</h2>

<div id="reviewSlider" class="carousel slide" data-bs-ride="carousel">
<div class="carousel-inner text-center">
<?php foreach($reviews as $index=>$r){ ?>
<div class="carousel-item <?php if($index==0) echo 'active'; ?>">
<div class="review-box">
<h5 class="fw-bold"><?php echo $r['nama']; ?></h5>
<p class="text-warning fs-5">★★★★★</p>
<p><?php echo $r['pesan']; ?></p>
</div>
</div>
<?php } ?>
</div>

<button class="carousel-control-prev" type="button" data-bs-target="#reviewSlider" data-bs-slide="prev">
<span class="carousel-control-prev-icon bg-dark rounded-circle"></span>
</button>
<button class="carousel-control-next" type="button" data-bs-target="#reviewSlider" data-bs-slide="next">
<span class="carousel-control-next-icon bg-dark rounded-circle"></span>
</button>

</div>
</div>
</section>