<h2 class="text-center mb-5 fw-bold">Food Menu</h2>

<div class="row g-4">

<?php
$menu_makanan = [

["Burger Beef","Juicy grilled beef burger","35000","https://images.unsplash.com/photo-1568901346375-23c9450c58cd"],
["Cheese Burger","Burger with melted cheese","36000","https://images.unsplash.com/photo-1550547660-d9450f859349"],
["Chicken Burger","Crispy chicken burger","33000","https://images.unsplash.com/photo-1606755962773-0a6c5e8b5b3b"],
["French Fries","Crispy potato fries","20000","https://images.unsplash.com/photo-1541592106381-b31e9677c0e5"],
["Chicken Wings","Spicy chicken wings","30000","https://images.unsplash.com/photo-1604908177078-2b2d5a0d3276"],
["Spaghetti Bolognese","Pasta with meat sauce","34000","https://images.unsplash.com/photo-1589302168068-964664d93dc0"],
["Carbonara Pasta","Creamy carbonara pasta","36000","https://images.unsplash.com/photo-1612874742237-6526221588e3"],
["Fried Rice","Indonesian fried rice","25000","https://images.unsplash.com/photo-1604908177522-4293c0b5d8f5"],
["Chicken Katsu","Japanese chicken katsu","32000","https://images.unsplash.com/photo-1604908177304-4b9d927d0b8c"],
["Club Sandwich","Triple layer sandwich","30000","https://images.unsplash.com/photo-1553909489-cd47e0ef937f"],
["Hot Dog","Sausage hot dog","28000","https://images.unsplash.com/photo-1550547660-3f4f8a1a0f0f"],
["Chicken Wrap","Chicken tortilla wrap","29000","https://images.unsplash.com/photo-1606755962773-3b5b1c8f0b0d"],
["Grilled Chicken","Grilled chicken with sauce","37000","https://images.unsplash.com/photo-1600891964599-f61ba0e24092"],
["Beef Steak","Tender beef steak","45000","https://images.unsplash.com/photo-1600891964092-4316c288032e"],
["Nuggets","Crispy chicken nuggets","24000","https://images.unsplash.com/photo-1625944525903-0f2e8b7f7f65"]

];

foreach($menu_makanan as $m){
?>

<div class="col-md-4">

<div class="card shadow-sm border-0 h-100">

<img src="<?= $m[3]; ?>" class="card-img-top" style="height:220px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold"><?= $m[0]; ?></h5>
<p class="text-muted"><?= $m[1]; ?></p>

<div class="d-flex justify-content-between align-items-center">

<span class="fw-bold text-success">Rp <?= $m[2]; ?></span>

<a href="#" class="btn btn-sm btn-dark">
Order
</a>

</div>

</div>

</div>

</div>

<?php } ?>

</div>