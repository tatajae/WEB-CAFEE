<h2 class="text-center mb-5 fw-bold">Dessert Menu</h2>

<div class="row g-4">

<?php
$menu_dessert = [

["Chocolate Cake","Rich chocolate layered cake","28000","https://images.unsplash.com/photo-1601979031925-424e53b6caaa"],
["Cheesecake","Creamy cheese cake","30000","https://images.unsplash.com/photo-1563729784474-d77dbb933a9e"],
["Red Velvet Cake","Soft red velvet cake","29000","https://images.unsplash.com/photo-1612197522593-9f6c6b3b6e89"],
["Tiramisu","Italian coffee dessert","32000","https://images.unsplash.com/photo-1571877227200-a0d98ea607e9"],
["Brownies","Fudgy chocolate brownies","25000","https://images.unsplash.com/photo-1606313564200-e75d5e30476c"],
["Waffle","Crispy waffle with syrup","27000","https://images.unsplash.com/photo-1506086679525-9c3c7f52a9b1"],
["Pancake","Fluffy pancake stack","26000","https://images.unsplash.com/photo-1528207776546-365bb710ee93"],
["Donut","Sweet glazed donut","18000","https://images.unsplash.com/photo-1505252585461-04db1eb84625"],
["Ice Cream","Vanilla ice cream scoop","20000","https://images.unsplash.com/photo-1497034825429-c343d7c6a68f"],
["Fruit Salad","Fresh mixed fruits","22000","https://images.unsplash.com/photo-1564093497595-593b96d80180"],
["Crepe","Thin french crepe","25000","https://images.unsplash.com/photo-1551024506-0bccd828d307"],
["Pudding","Soft caramel pudding","19000","https://images.unsplash.com/photo-1587241321921-91a834d6d191"],
["Cupcake","Mini sweet cupcake","21000","https://images.unsplash.com/photo-1519864600265-abb23847ef2c"],
["Macaron","French colorful macaron","23000","https://images.unsplash.com/photo-1559622214-f8a9850965bb"],
["Banana Split","Ice cream with banana","30000","https://images.unsplash.com/photo-1570197788417-0e82375c9371"]

];

foreach($menu_dessert as $m){
?>

<div class="col-md-4">

<div class="card shadow-sm border-0 h-100">

<img src="<?= $m[3]; ?>" class="card-img-top" style="height:220px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold"><?= $m[0]; ?></h5>
<p class="text-muted"><?= $m[1]; ?></p>

<div class="d-flex justify-content-between align-items-center">

<span class="fw-bold text-success">Rp <?= $m[2]; ?></span>

<a href="#" class="btn btn-sm btn-dark">
Order
</a>

</div>

</div>

</div>

</div>

<?php } ?>

</div>