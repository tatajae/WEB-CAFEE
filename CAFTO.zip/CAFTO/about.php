<?php
$tahun = date("Y");
$menu = "home.php";
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>About - Cafe & Resto</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

.hero{
background:#3f5336;
color:white;
padding:100px 0;
text-align:center;
}

.about-img{
border-radius:10px;
}

.feature{
padding:20px;
border-radius:10px;
transition:0.3s;
}

.feature:hover{
background:#f8f9fa;
transform:translateY(-5px);
}

</style>

</head>
<body>

<!-- HERO -->
<section class="hero">
<div class="container">
<h1 class="display-4">Tentang Kami</h1>
<p>Kenali lebih dekat Cafe & Resto kami</p>
</div>
</section>


<!-- ABOUT -->
<section class="container py-5">

<div class="row align-items-center">

<div class="col-md-6">
<img src="https://images.unsplash.com/photo-1559925393-8be0ec4767c8"
class="img-fluid about-img shadow">
</div>

<div class="col-md-6">

<h2>Tentang Cafe Kami</h2>

<p>
Cafe & Resto kami berdiri dengan tujuan memberikan pengalaman
kuliner terbaik bagi setiap pelanggan.
</p>

<p>
Kami menyediakan berbagai menu makanan dan minuman berkualitas
dengan bahan terbaik serta pelayanan yang ramah.
</p>

<p>
Tempat kami juga nyaman untuk bersantai bersama teman,
keluarga, maupun bekerja dengan suasana santai.
</p>

</div>

</div>

</section>


<!-- VISI MISI -->
<section class="bg-light py-5">

<div class="container text-center">

<h2 class="mb-4">Visi & Misi</h2>

<div class="row">

<div class="col-md-6">
<h4>Visi</h4>
<p>
Menjadi cafe dan restoran terbaik dengan pelayanan
dan kualitas makanan yang memuaskan pelanggan.
</p>
</div>

<div class="col-md-6">
<h4>Misi</h4>
<p>
Memberikan pelayanan terbaik dan menciptakan
tempat yang nyaman bagi pengunjung.
</p>
</div>

</div>

</div>

</section>


<!-- KEUNGGULAN -->
<section class="container py-5">

<h2 class="text-center mb-5">Keunggulan Kami</h2>

<div class="row text-center">

<div class="col-md-4">

<div class="feature shadow-sm">
<h4>☕ Menu Berkualitas</h4>
<p>Kami menggunakan bahan pilihan dengan rasa terbaik.</p>
</div>

</div>

<div class="col-md-4">

<div class="feature shadow-sm">
<h4>😊 Pelayanan Ramah</h4>
<p>Staff kami siap melayani pelanggan dengan ramah.</p>
</div>

</div>

<div class="col-md-4">

<div class="feature shadow-sm">
<h4>🏡 Tempat Nyaman</h4>
<p>Suasana cafe nyaman untuk bersantai.</p>
</div>

</div>

</div>

</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>