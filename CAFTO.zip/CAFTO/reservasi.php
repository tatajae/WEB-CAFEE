<!DOCTYPE html>
<html>
<head>
<title>Reservasi Cafe</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:linear-gradient(rgba(0,0,0,0.6),rgba(0,0,0,0.6)),
url('https://images.unsplash.com/photo-1509042239860-f550ce710b93');
background-size:cover;
color:white;
}

.box{
background:rgba(255,255,255,0.9);
padding:40px;
border-radius:15px;
margin-top:80px;
color:black;
box-shadow:0px 10px 25px rgba(0,0,0,0.4);
}

h2{
text-align:center;
margin-bottom:30px;
font-weight:bold;
}

.btn-reservasi{
background:#6f4e37;
color:white;
font-weight:bold;
}

</style>

</head>

<body>

<div class="container">

<div class="col-md-6 mx-auto box">

<h2>Reservasi Meja Cafe</h2>

<form action="proses_reservasi.php" method="POST">

<div class="mb-3">
<label>Nama Lengkap</label>
<input type="text" name="nama" class="form-control" required>
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="mb-3">
<label>No HP</label>
<input type="text" name="no_hp" class="form-control" required>
</div>

<div class="mb-3">
<label>Tanggal Reservasi</label>
<input type="date" name="tanggal" class="form-control" required>
</div>

<div class="mb-3">
<label>Jam</label>
<input type="time" name="jam" class="form-control" required>
</div>

<div class="mb-3">
<label>Jumlah Orang</label>
<input type="number" name="jumlah_orang" class="form-control" required>
</div>

<div class="mb-3">
<label>Catatan</label>
<textarea name="catatan" class="form-control"></textarea>
</div>

<button class="btn btn-reservasi w-100">Kirim Reservasi</button>

</form>

</div>

</div>

</body>
</html>