<?php
if(isset($_GET['menu'])){
$menu=$_GET['menu'];
}
else{
$menu="";
}
if($menu=="About"){
	include"about.php";
}
else if($menu=="Menu"){
	include"menu.php";
}
else if($menu=="Coffe"){
	include"coffe.php";
}
else if($menu=="Noncoffe"){
	include"noncoffe.php";
}
else if($menu=="Makanan"){
	include"makanan.php";
}
else if($menu=="Dessert"){
	include"dessert.php";
}
else if($menu=="Reservasi"){
	include"reservasi.php";
}
else if($menu=="Gallery"){
	include"gallery.php";
}
else if($menu=="contact"){
	include"contact.php";
}
else if($menu=="login"){
	include "admin/login.php";
}

?>