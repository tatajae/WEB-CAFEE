<h2 class="text-center mb-5 fw-bold">Non Coffee Menu</h2>

<div class="row g-4">

<?php
$menu_noncoffee = [

["Chocolate","Hot chocolate creamy","25000","https://images.unsplash.com/photo-1517578239113-b03992dcdd25"],
["Green Tea Latte","Matcha with milk","26000","https://images.unsplash.com/photo-1558160074-4d7d8bdf4256"],
["Thai Tea","Sweet thai milk tea","23000","https://images.unsplash.com/photo-1572490122747-3968b75cc699"],
["Taro Latte","Purple taro drink","24000","https://images.unsplash.com/photo-1627308595229-7830a5c91f9f"],
["Red Velvet Latte","Creamy red velvet","27000","https://images.unsplash.com/photo-1617196035154-1e84c6c7b9f7"],
["Vanilla Milk","Sweet vanilla fresh milk","22000","https://images.unsplash.com/photo-1551024601-bec78aea704b"],
["Strawberry Milk","Fresh strawberry milk","23000","https://images.unsplash.com/photo-1497534446932-c925b458314e"],
["Mango Smoothie","Fresh mango blend","28000","https://images.unsplash.com/photo-1553530666-ba11a7da3888"],
["Avocado Juice","Creamy avocado","26000","https://images.unsplash.com/photo-1598514982841-1b6b3b5b0b38"],
["Orange Juice","Fresh squeezed orange","20000","https://images.unsplash.com/photo-1600275669439-14e40452d20b"],
["Lemon Tea","Iced lemon tea","21000","https://images.unsplash.com/photo-1513635269975-59663e0ac1ad"],
["Peach Tea","Sweet peach tea","22000","https://images.unsplash.com/photo-1590080875852-ba44f83ff2b5"],
["Mineral Water","Pure bottled water","10000","https://images.unsplash.com/photo-1564419320408-38e24e0386f7"],
["Sparkling Soda","Refreshing soda drink","19000","https://images.unsplash.com/photo-1581009137042-c552e485697a"],
["Blue Ocean","Blue syrup soda","25000","https://images.unsplash.com/photo-1625944196210-7c5c5d14d3b4"]

];

foreach($menu_noncoffee as $m){
?>

<div class="col-md-4">

<div class="card shadow-sm border-0 h-100">

<img src="<?= $m[3]; ?>" class="card-img-top" style="height:220px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold"><?= $m[0]; ?></h5>
<p class="text-muted"><?= $m[1]; ?></p>

<div class="d-flex justify-content-between align-items-center">

<span class="fw-bold text-success">Rp <?= $m[2]; ?></span>

<a href="#" class="btn btn-sm btn-dark">
Order
</a>

</div>

</div>

</div>

</div>

<?php } ?>

</div>