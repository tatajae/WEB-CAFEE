<h2 class="text-center mb-5 fw-bold">Coffee Menu</h2>

<div class="row g-4">

<?php
$menu_coffee = [
["Espresso","Strong & bold coffee","18000","https://images.unsplash.com/photo-1511920170033-f8396924c348"],
["Americano","Espresso with hot water","20000","https://images.unsplash.com/photo-1498804103079-a6351b050096"],
["Cappuccino","Espresso with milk foam","25000","https://images.unsplash.com/photo-1534778101976-62847782c213"],
["Latte","Smooth milky coffee","25000","https://images.unsplash.com/photo-1509042239860-f550ce710b93"],
["Mocha","Coffee with chocolate","28000","https://images.unsplash.com/photo-1572441713132-51c75654db73"],
["Caramel Macchiato","Sweet caramel coffee","30000","https://images.unsplash.com/photo-1461023058943-07fcbe16d735"],
["Flat White","Velvety microfoam","26000","https://images.unsplash.com/photo-1485808191679-5f86510681a2"],
["Affogato","Espresso with ice cream","32000","https://images.unsplash.com/photo-1517705008128-361805f42e86"],
["Cold Brew","Slow brew cold coffee","27000","https://images.unsplash.com/photo-1461988625982-7e46a099bf4f"],
["Vietnam Drip","Traditional drip coffee","22000","https://images.unsplash.com/photo-1507914372368-b2b085b925a1"]
];

foreach($menu_coffee as $m){
?>

<div class="col-md-4">

<div class="card shadow-sm border-0 h-100">

<img src="<?= $m[3]; ?>" class="card-img-top" style="height:220px; object-fit:cover;">

<div class="card-body">

<h5 class="fw-bold"><?= $m[0]; ?></h5>
<p class="text-muted"><?= $m[1]; ?></p>

<div class="d-flex justify-content-between align-items-center">

<span class="fw-bold text-success">Rp <?= $m[2]; ?></span>

<a href="#" class="btn btn-sm btn-dark">
Order
</a>

</div>

</div>

</div>

</div>

<?php } ?>

</div>