<?php
$conn = mysqli_connect("localhost","root","","caffe&resto");

if(!$conn){
    echo "Koneksi gagal";
}
?>